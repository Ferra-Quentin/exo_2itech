import {libraryModel} from './library.model';

export const library:libraryModel[] = [{
    id:1,
    user:1,
    name:"Bibliothèque"
},{
    id:2,
    user:2,
    name:"bibliothèque 2"
}]
