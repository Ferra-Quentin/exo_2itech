import {LivresModel} from '../livres/livres.model';

export class libraryModel{
    id:number;
    user:number;
    name:string;
}

