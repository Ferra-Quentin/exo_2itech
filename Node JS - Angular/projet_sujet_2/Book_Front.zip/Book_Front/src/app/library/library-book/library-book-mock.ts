import {LibraryBookModel} from "./library-book.model"

export const libraryBook:LibraryBookModel[] = [
    {
        id:1,
        livres:1,
        library:1,
        read:true
    },
    {
        id:2,
        livres:3,
        library:1,
        read:false
    },
    {
        id:3,
        livres:2,
        library:2,
        read:false
    }
]
