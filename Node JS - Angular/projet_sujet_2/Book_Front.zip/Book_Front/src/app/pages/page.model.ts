export class pageModel{
    id: number;
    number:number;
    image:string;
    bookId:number;
}
