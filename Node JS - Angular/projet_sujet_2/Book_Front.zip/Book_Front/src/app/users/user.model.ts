export class userModel{
    id:number;
    firstname:string;
    lastname:string;
    username:string;
    password:string;
    role:string;
    idLibrary:number;
}
