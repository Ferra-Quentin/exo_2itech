export class LivresModel{
    id: number;
    name:string;
    author:string;
    releaseDate: Date;
    type:string[];
    downloadNumber:number;
    readNumber:number
}
